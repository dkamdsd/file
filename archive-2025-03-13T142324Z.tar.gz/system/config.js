//© KAGENOUDEV-2025
//===========================//
global.prefa = ["","!",".",",","🐤","🗿"]
global.owner = ["62882003689843"]
global.NamaOwner = "VSL V22"
global.namabot = "VSL V22"
//===========================//
//Global Mess
global.mess = {
 ingroup: "It's not funny, this feature is only for groups💢",
 admin: "not funny, only group admins use this feature💢",
 owner: "Wow! You're not my owner🗣️",
 premium: "you are not a premium user",
 success: 'Success bro✅',
}
//===========================//